<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;

use App\Entity\Events;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

class EventController extends AbstractController
{
    /**
     * @Route("/",  name="index_page")
     */
    public function Homepage()
    {
        $events = $this->getDoctrine()
            ->getRepository(Events::class)
            ->findAll();
        return $this->render('event/index.html.twig', array("events"=>$events));
    }

    /**
     * @Route("/list/{category}", name="list_page", defaults={"category"="All"})
     */
    public function showAction($category)
    {
        switch ($category){
            case "Music":
            case "Movie":
            case "Theater":
            case "Sport":

            $events = $this->getDoctrine()
                    ->getRepository(Events::class)
                    ->findBy(array('category'=>$category));
                return $this->render('event/list.html.twig', array("events"=>$events));

            default:
                $events = $this->getDoctrine()
                    ->getRepository(Events::class)
                    ->findAll();
                return $this->render('event/list.html.twig', array("events"=>$events));
        }
    }
    /**
     * @Route("/create", name="create_page")
     */
    public  function createAction(Request $request)
    {
        $event = new Events;
        $form = $this->createFormBuilder($event)
            ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('url', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('phone', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('zip', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('city', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('country', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('category', ChoiceType::class, array('choices'=>array('MUSIC'=>'MUSIC', 'SPORT'=>'SPORT', 'MOVIE'=>'MOVIE', 'THEATER'=>'THEATER'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
            ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('date', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))
            ->add('save', SubmitType::class, array('label'=> 'Create Event', 'attr' => array('class'=> 'btn btn-info', 'style'=>'margin-bottom:15px')))
            ->getForm();
        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){

            $name = $form['name']->getData();
            $category = $form['category']->getData();
            $email = $form['email']->getData();
            $phone = $form['phone']->getData();
            $description = $form['description']->getData();
            $image = $form['image']->getData();
            $url = $form['url']->getData();
            $capacity = $form['capacity']->getData();
            $address = $form['address']->getData();
            $zip = $form['zip']->getData();
            $city = $form['city']->getData();
            $country = $form['country']->getData();
            $now = new\DateTime('now');


            $event->setName($name);
            $event->setCategory($category);
            $event->setDescription($description);
            $event->setEmail($email);
            $event->setPhone($phone);
            $event->setImage($image);
            $event->setUrl($url);
            $event->setCapacity($capacity);
            $event->setZip($zip);
            $event->setAddress($address);
            $event->setCity($city);
            $event->setCountry($country);
            $event->setDate($now);
            $em = $this->getDoctrine()->getManager();
            $em->persist($event);
            $em->flush();
            $this->addFlash(
                'notice',
                'event Added'
            );
            return $this->redirectToRoute('index_page');
        }

        return $this->render('event/create.html.twig', array('form' => $form->createView()));    }

    /**
     * @Route("/edit/{id}", name="edit_page")
     */
    public  function editAction($id, Request $request)
    {
        $event = $this->getDoctrine()
            ->getRepository(Events::class)
            ->find($id);
        $now = new\DateTime('now');

        $event->setName($event->getName());
        $event->setCategory($event->getCategory());
        $event->setDescription($event->getDescription());
        $event->setEmail($event->getEmail());
        $event->setPhone($event->getPhone());
        $event->setImage($event->getImage());
        $event->setUrl($event->getUrl());
        $event->setCapacity($event->getCapacity());
        $event->setZip($event->getZip());
        $event->setAddress($event->getAddress());
        $event->setCity($event->getCity());
        $event->setCountry($event->getCountry());
        $event->setDate($now);

        $form = $this->createFormBuilder($event)
            ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('url', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('phone', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('zip', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('city', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('country', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('category', ChoiceType::class, array('choices'=>array('MUSIC'=>'MUSIC', 'SPORT'=>'SPORT', 'MOVIE'=>'MOVIE', 'THEATER'=>'THEATER'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
            ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('date', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))
            ->add('save', SubmitType::class, array('label'=> 'Edit Event', 'attr' => array('class'=> 'btn btn-info', 'style'=>'margin-bottom:15px')))
            ->getForm();
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $name = $form['name']->getData();
            $category = $form['category']->getData();
            $email = $form['email']->getData();
            $phone = $form['phone']->getData();
            $description = $form['description']->getData();
            $image = $form['image']->getData();
            $url = $form['url']->getData();
            $capacity = $form['capacity']->getData();
            $address = $form['address']->getData();
            $zip = $form['zip']->getData();
            $city = $form['city']->getData();
            $country = $form['country']->getData();
            $now = new\DateTime('now');

            $em = $this->getDoctrine()->getManager();
            $cake = $em->getRepository('App:Events')->find($id);
            $event->setName($name);
            $event->setCategory($category);
            $event->setDescription($description);
            $event->setEmail($email);
            $event->setPhone($phone);
            $event->setImage($image);
            $event->setUrl($url);
            $event->setCapacity($capacity);
            $event->setZip($zip);
            $event->setAddress($address);
            $event->setCity($city);
            $event->setCountry($country);
            $event->setDate($now);

            $em->flush();
            $this->addFlash(
                'notice',
                'Event Updated'
            );
            return $this->redirectToRoute('index_page');
        }
        return $this->render('event/edit.html.twig', array('event' => $event, 'form' => $form->createView()));


    }

    /**
     * @Route("/details/{id}", name="details_page")
     */
    public  function detailsAction($id)
    {
        $event = $this->getDoctrine()->getRepository('App:Events')->find($id);
        return $this->render('event/details.html.twig', array('event' => $event));
    }
    /**
     * @Route("/delete/{id}", name="delete_page")
     */
    public function deleteAction($id){
        $em = $this->getDoctrine()->getManager();
        $event = $em->getRepository('App:Events')->find($id);
        $em->remove($event);
        $em->flush();
        $this->addFlash(
            'notice',
            'Event Removed'
        );
        return $this->redirectToRoute('index_page');
    }


}
