$(document).ready(function(){
    $('.dropdown-item').click(function(){
        let category = $(this).data().value;
        {
            $.ajax({
                url:"/list/"+ category,
                method:"GET",
                success:function(response){
                    $('#box').html(response);
                }
            });
        }
    });
});
